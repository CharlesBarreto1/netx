<!-- Obrigado pela contribuição! Preencha as seções abaixo. -->

## 🎯 O que muda?

<!-- Descreva o objetivo da PR em 1-3 frases. -->

## 🔗 Issue relacionada

Closes #

## 🧪 Como testar?

<!-- Passos para o revisor validar localmente. -->

## 📋 Checklist

- [ ] Segui as convenções de Conventional Commits
- [ ] Adicionei/atualizei testes
- [ ] Atualizei a documentação (se aplicável)
- [ ] Rodei `npm run lint` e `npm run test` localmente
- [ ] Considerei impacto multi-tenant (isolamento de dados)
- [ ] Considerei impacto de segurança (autenticação, permissões, secrets)
- [ ] Verifiquei logs de auditoria para ações sensíveis
